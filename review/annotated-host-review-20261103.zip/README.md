# Annotated host review bundle — 2026-11-03

Review material only. Not a release, merge or production host commit.

- Host base: 27c75c3364511dd77e2ec0c5b8f314f529df6291.
- Original uncommitted V1 runtime: all 27 manifest runtime hashes matched.
- Plugin runtime: 130d12bf9b4150aa7349365b2200bda80e153feb.
- Plugin QA script and documentation: c54bba3897e39de8e7e8f1c1ed633e839fcb399e.
- OCCT: occt-wasm 5.7.1.
- host-delta.patch contains the 21 modified and 13 new host source/contract/test
  files, including the QA-only correction to the normal helper and both fixtures.
  It was checked with git apply --check against the exact base.
- The two patch files under patches/ document corrections relative to the
  original host snapshot; the Vite cache setting is isolated QA infrastructure.
- The real-kernel reversed-face test accepts the outward normal and rejects its
  inverse. Host Vitest: 17 passed after restricting Vite's local filesystem
  allowance to the QA checkout and its existing dependency junction.
- The real-controller source-app run (final-exact-identity.json) passed 14
  checks: STEP reversed face, Zebra, note, deformation, Apply, Undo/Redo, Save,
  Load, UUID/body/feature identity and valid CAD. The saved project is synthetic.
- The initial run stopped because it checked before asynchronous revalidation;
  both the initial and successful results are retained.
- Compiled desktop, arbitrary geometries and final host publication are NOT
  qualified by this bundle. The host owner must review and publish its own work.
- No .env, credentials, dependencies, browser profiles or user projects included.
- Local user paths in JSON results are redacted; the manifest records original
  local result hashes and SHA256SUMS records the redacted archive members.
